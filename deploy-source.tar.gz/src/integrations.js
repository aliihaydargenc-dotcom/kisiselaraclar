export const integrations = {
  mediabunny: {
    id: "mediabunny",
    name: "Mediabunny",
    source: "Vanilagy/mediabunny",
    sourceUrl: "https://github.com/Vanilagy/mediabunny",
    version: "1.59.1",
    license: "MPL-2.0",
    execution: "browser-webcodecs",
    networkRequired: false,
    dataLeavesDevice: false,
    purpose: "Ses/video metadata okuma, kırpma, kapsayıcı/codec dönüşümü ve video yeniden boyutlandırma"
  },
  native: {
    id: "native",
    name: "Web Platform API",
    source: "Tarayıcı yerleşik API'leri",
    sourceUrl: "https://developer.mozilla.org/",
    version: "tarayıcı",
    license: "Web standardı",
    execution: "browser",
    networkRequired: false,
    dataLeavesDevice: false
  },
  "design-native": {
    id: "design-native",
    name: "Native UI Design Engine",
    source: "Web Platform + WCAG 2.2 ilkeleri",
    sourceUrl: "https://www.w3.org/TR/WCAG22/",
    version: "P14",
    license: "Bağımlılık yok",
    execution: "browser",
    networkRequired: false,
    dataLeavesDevice: false,
    purpose: "Renk, kontrast, gradient, shadow, tipografi, spacing, radius ve buton CSS üretimi"
  },
  "data-lab-native": {
    id: "data-lab-native",
    name: "Local Data Lab",
    source: "PapaParse + Web Platform",
    sourceUrl: "https://github.com/mholt/PapaParse",
    version: "P14 / PapaParse 5.7.0",
    license: "MIT + Web standardı",
    execution: "browser",
    networkRequired: false,
    dataLeavesDevice: false,
    purpose: "CSV profil, kalite, eksik değer, duplicate, kolon analizi ve dosya karşılaştırma"
  },
  tesseractjs: {
    id: "tesseractjs",
    name: "Tesseract.js",
    source: "naptha/tesseract.js",
    sourceUrl: "https://github.com/naptha/tesseract.js",
    version: "7.0.0",
    license: "Apache-2.0",
    execution: "browser-worker-wasm",
    networkRequired: false,
    dataLeavesDevice: false,
    purpose: "Görsel ve PDF sayfasından Türkçe/İngilizce OCR metni çıkarma",
    assets: "worker, WASM core ve tur/eng traineddata aynı origin üzerinde paketlenir"
  },
  "qrcode-generator": {
    id: "qrcode-generator",
    name: "qrcode-generator",
    source: "kazuhikoarase/qrcode-generator",
    sourceUrl: "https://github.com/kazuhikoarase/qrcode-generator",
    version: "2.0.4",
    license: "MIT",
    execution: "browser",
    networkRequired: false,
    dataLeavesDevice: false,
    purpose: "Metin ve bağlantılardan SVG QR kod üretme"
  },
  "zxing-browser": {
    id: "zxing-browser",
    name: "ZXing Browser",
    source: "zxing-js/browser",
    sourceUrl: "https://github.com/zxing-js/browser",
    version: "0.2.1 + library 0.23.0",
    license: "MIT / Apache-2.0",
    execution: "browser",
    networkRequired: false,
    dataLeavesDevice: false,
    purpose: "Görsel dosyalarından çok formatlı QR ve barkod okuma"
  },
  fflate: {
    id: "fflate",
    name: "fflate",
    source: "101arrowz/fflate",
    sourceUrl: "https://github.com/101arrowz/fflate",
    version: "0.8.3",
    license: "MIT",
    execution: "browser",
    networkRequired: false,
    dataLeavesDevice: false,
    purpose: "ZIP oluşturma/çıkarma ve GZIP sıkıştırma/açma"
  },
  "image-native": {
    id: "image-native",
    name: "Web Platform Image API",
    source: "Canvas, createImageBitmap ve Blob API",
    sourceUrl: "https://developer.mozilla.org/",
    version: "tarayıcı",
    license: "Web standardı",
    execution: "browser",
    networkRequired: false,
    dataLeavesDevice: false,
    purpose: "Görsel kırpma, yeniden boyutlandırma, sıkıştırma, format dönüşümü ve metadata temizleme"
  },
  exifreader: {
    id: "exifreader",
    name: "ExifReader",
    source: "mattiasw/ExifReader",
    sourceUrl: "https://github.com/mattiasw/ExifReader",
    version: "4.45.2",
    license: "MPL-2.0",
    execution: "browser",
    networkRequired: false,
    dataLeavesDevice: false,
    purpose: "Görsel EXIF/IPTC/XMP metadata alanlarını yerel olarak okuma"
  },
  papaparse: {
    id: "papaparse",
    name: "PapaParse",
    source: "mholt/PapaParse",
    sourceUrl: "https://github.com/mholt/PapaParse",
    version: "5.7.0",
    license: "MIT",
    execution: "browser",
    networkRequired: false,
    dataLeavesDevice: false,
    purpose: "CSV ayrıştırma, delimiter algılama ve CSV → JSON dönüşümü"
  },
  pdfjs: {
    id: "pdfjs",
    name: "PDF.js",
    source: "mozilla/pdf.js",
    sourceUrl: "https://github.com/mozilla/pdf.js",
    version: "6.3.289",
    license: "Apache-2.0",
    execution: "browser-worker",
    networkRequired: false,
    dataLeavesDevice: false,
    purpose: "PDF sayfalarını tarayıcıda görüntüleme"
  },
  pdflib: {
    id: "pdflib",
    name: "pdf-lib",
    source: "Hopding/pdf-lib",
    sourceUrl: "https://github.com/Hopding/pdf-lib",
    version: "1.17.1",
    license: "MIT",
    execution: "browser",
    networkRequired: false,
    dataLeavesDevice: false,
    purpose: "PDF birleştirme, sayfa çıkarma ve döndürme"
  }
};

export function getIntegration(id = "native") {
  return integrations[id] || integrations.native;
}
